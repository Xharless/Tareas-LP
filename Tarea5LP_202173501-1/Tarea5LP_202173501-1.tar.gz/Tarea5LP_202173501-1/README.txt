Nombre: Carlos Andrés Arévalo Guajardo
Rol: 202173501-1

Todas las preguntas estan implementadas y funcionan correctamente menos la pregunta 4, ya que la implementacion está echa pero no funciona como corresponde, con respecto a las demas preguntas, se probaron con distintos ejemplos pero se asumio que habrias entradas correctas (no entradas de simbolos ni letras o cosas raras). Con respecto a la pregunta 2 y 3, se tomo la misma cerradura que en el ejemplo del pdf.