Nombre: Carlos Andrés Arévalo Guajardo
Rol: 202173501-1

------------EJECUCION------------
1.- Se programo en eclipse version 2023-09, ademas de ocupar la version de javac 19.0.2
2.- Al momento de ejecutar el codigo con una terminal, solo hay que hacer make run y emperzara a correr

------------JUEGO------------
1.- Se toma en consideracion que hay 2 formas de aumentar la capacidad de tus pikinims, una es cuando es derrotado el enemigo, y la otra con las pildoras, con esto puedes aumentar la capacidad de cualquier pikinim, pero si tus pikinims se van a una cantidad de 0, la unica forma de aumentar su capacidad es con las pildoras
2.- Cuando no se puede romper una muralla sale el mensaje que no puedes, por lo que deberas moverte otra ves en el mismo sentido para volver a la casilla anterior (se que es extraño pero es la unica solucion que encontre), pero si lo rompes, puedes moverte libremente para la izquierda o la derecha.